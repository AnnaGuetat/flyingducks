 
# AI Driving Olympics

<a href="http://aido.duckietown.org"><img width="200" src="https://www.duckietown.org/wp-content/uploads/2018/07/AIDO-768x512.png"/></a>

Deprecated. Please see the `local/` [directory of the Duckietown AIDO Baseline](https://github.com/duckietown/challenge-aido_LF-baseline-duckietown)

